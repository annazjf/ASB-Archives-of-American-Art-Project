from bs4 import BeautifulSoup
import requests

headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0)   Gecko/20100101 Firefox/78.0", 
"Referer": "https://www.google.com"}


all_items_metadata = []
# open txt file and turn into list of paths
def text_file_to_list(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        path_list = content.splitlines()
    return path_list

def get_metadata_from_items(path_list):
    base_url = 'https://openlibrary.org'
    for path in range(0,10):
        metadata = {}
        url = base_url + path_list[path]
        r = requests.get(url, headers=headers)
        print(r.status_code, r.url)

        soup = BeautifulSoup(r.text, 'html.parser')

        metadata['title'] = soup.find('h1', class_='work-title').text
        metadata['date_published'] = soup.find(attrs={'itemprop': 'datePublished'}).text
        metadata['publisher'] = soup.find(attrs={'itemprop': 'publisher'}).text

        print(metadata)


path_list = text_file_to_list("search-results.txt")
get_metadata_from_items(path_list)