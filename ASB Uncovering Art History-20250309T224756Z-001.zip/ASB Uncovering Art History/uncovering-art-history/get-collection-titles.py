import requests
from bs4 import BeautifulSoup

headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0)   Gecko/20100101 Firefox/78.0", 
"Referer": "https://www.google.com"}

url = "https://www.aaa.si.edu/search/collections?edan_fq%5B1%5D=p.edanmdm.descriptivenonrepeating.record_id%3AAAADCD_coll_%2A&stype=search-collections&page="
urls = []

def download_json(url):

    for page in range(0, 539):


        r = requests.get(url + str(page), headers=headers)
        print(r.status_code, r.url)

        soup = BeautifulSoup(r.text, 'html.parser')

        titles_full_block = soup.find_all('h3', class_ = 'title')


        for t in titles_full_block:
            urls.append(t.text.strip())


download_json(url)
with open('new-collection-titles.txt', 'w', encoding='utf-8') as f:
    for u in urls:
        f.write(u + '\n')