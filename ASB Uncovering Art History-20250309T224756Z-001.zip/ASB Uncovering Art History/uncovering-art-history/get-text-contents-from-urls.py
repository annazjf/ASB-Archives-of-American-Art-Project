from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
import csv

# HTTP headers that allow our scraper to appear more "human"
headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0)   Gecko/20100101 Firefox/78.0", 
"Referer": "https://www.google.com"}

'''

This function takes our csv file of search results and turns it into a list of urls
that we can loop through, where file is the name of the file and column_index is the
column that we want to grab.

In our case, this is the snippets_url column, which has index 5.

'''
def list_of_urls_from_csv(file, column_index):

    # Open the file in read-only mode
    with open(file, 'r', encoding='utf-8') as csv_file:

        # Create a CSV reader object
        reader = csv.reader(csv_file)

        # Skip the first line with column names
        next(reader)

        # Generate a list of all values in specified column
        urls = [row[column_index] for row in reader]

    # Return list of urls
    return urls

'''

This function "clicks on" each url in a list of urls and grabs snippets
with "Archives of American Art" that appear in the full text. It returns a full
list of all snippet contents. If there are any urls that the reader cannot
pull from, they'll be noted in a separate file called issues.txt.

Example url: https://archive.org/stream/metropolitanlive0000zuri?ref=ol&access=1#search/%22Archives+of+American+Art%22

'''
def get_snippets_from_urls(list_of_urls):

    # Create empty list for each page's individual snippets
    snippets = []

    # Create empty list for problematic urls
    issues = []

    # Change Selenium setting to headless mode to avoid new browser tabs popping up on screen
    options = Options()
    options.add_argument("--headless")

    # Set counter to keep track of how many urls have been completed
    counter = 1

    # Loop through list of urls
    for url in list_of_urls:

        # Create new row to add to csv
        row = []

        # Progress check
        print('grabbing snippets for', url)

        # Create driver session
        driver = webdriver.Chrome(options=options)

        try:

            # Send driver to url (i.e. open up the page)
            driver.get(url)
            # Have driver wait for max 15 seconds for all page features to load
            driver.implicitly_wait(15)

            # Follow shadow-root trail to get to the list of text snippets
            root1=driver.find_element(By.CSS_SELECTOR, "ia-book-theater[class='focus-on-child-only']").shadow_root
            root2=root1.find_element(By.CSS_SELECTOR, "ia-bookreader[class='focus-on-child-only']").shadow_root
            root3=root2.find_element(By.CSS_SELECTOR, "iaux-item-navigator").shadow_root
            root4=root3.find_element(By.CSS_SELECTOR, "ia-menu-slider").shadow_root
            root5=root4.find_element(By.CSS_SELECTOR, "ia-book-search-results").shadow_root

            # Isolate each snippet and page number
            all_items = root5.find_elements(By.CSS_SELECTOR, "p")

            # Create list of snippets
            # Each list item is formatted as such:
                # {'Page #': 'Snippet Content'}
                # Example: {'Page 15': 'Lockwood de Forest Papers, 1858-1978, Archives of American Art, Smithsonian Institution, Washington, D.C.'}
            snippets = [{all_items[i].text: all_items[i+1].text} for i in range(0, len(all_items), 2)]

            # Add number of snippets and snippets content to row
            row.append(len(snippets))
            row.append(snippets)

            # Write row to cumulative snippets.csv file (this is so we don't lose the data or progress when running a big script)
            with open('snippets.csv', 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(row)

            # Progress check
            print(counter, 'found', str(len(snippets)), 'snippets!')
            counter += 1

            # Close driver
            driver.close()

        # If there are issues...
        except:

            # Add url to issues list
            issues.append(url)

            # Add list of snippets for each url to full list of all url snippets
            row.append(snippets)

            # Calculate and add number of snippets for each url to list
            row.append(len(snippets))

            # Add empty list of snippets and count 0 to larger lists to prevent dataframe discontinuity
            with open('snippets.csv', 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(row)

            # Feedback
            print(f"{counter} could not get snippets for {url}")
            counter += 1

            # Close driver
            driver.close()

    # After all urls have been checked, add problematic urls to issues.txt
    with open('issues.txt', 'a', encoding='utf-8') as f:
        for i in issues:
            f.write(i + '\n')

# The name of the file we are working with. This will likely be 'search-results.csv' generated from the get-urls-from-open-library.py script
filename = 'search-results-batch-2.csv'

# Execute functions above
urls = list_of_urls_from_csv(filename, 5)
get_snippets_from_urls(urls)

    