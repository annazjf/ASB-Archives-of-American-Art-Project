import requests
from bs4 import BeautifulSoup
import csv

# HTTP headers that allow our scraper to appear more "human"
headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0)   Gecko/20100101 Firefox/78.0", 
"Referer": "https://www.google.com"}

# Base url to enter search query
url = "https://openlibrary.org/search/inside/"

# Search query
parameters = {'q': '\"Archives of American Art\"'}

# Fieldnames for final csv
fieldnames = ['title', 'url', 'author', 'date_published', 'publisher', 'snippets_url']

'''

This is a function that loops through search result pages for the query
"Archives of American Art" and grabs relevant information.

'''
def get_items(url):

    base_url = 'https://openlibrary.org'

    # This format is easier for the computer to read in a url
    encoded_url = "%22Archives+of+American+Art%22"

    # loop through search result pages
    for page in range(1, 335):

        parameters['page'] = str(page)

        r = requests.get(url, params=parameters, headers=headers)
        print(r.status_code, r.url)

        soup = BeautifulSoup(r.text, 'html.parser')

        for result in soup.find_all(class_='sri__main'):
            snippets = []
            snippets = result.find(class_='fsi-snippet__main fsi-snippet__full-results')
            snippets_url = snippets.find(class_='fsi-snippet__link')['href']
            snippets_url = snippets_url.split('"')[0]
            snippets_url = snippets_url + encoded_url

            item_dict = {}
            try:
                item_dict['author'] = result.find(class_='bookauthor').text.strip().replace('\n', '').replace('by ', '')
            except:
                item_dict['author'] = "Not found"

            item_dict['snippets_url'] = snippets_url

            item_url = base_url + result.find(class_='results')['href']
            item_dict['url'] = item_url

            more_metadata = get_metadata_from_item(item_url)

            item_dict.update(more_metadata)

            with open("search-results.csv", "a", newline="", encoding='utf-8') as f:
                w = csv.DictWriter(f, fieldnames)
                w.writerow(item_dict)

def get_metadata_from_item(path):

    metadata = {}
    r = requests.get(path, headers=headers)
    print(r.status_code, r.url)

    soup = BeautifulSoup(r.text, 'html.parser')
    try:
        metadata['title'] = soup.find('h1', class_='work-title').text
    except:
        metadata['title'] = "Not found"
    try:
        metadata['date_published'] = soup.find(attrs={'itemprop': 'datePublished'}).text
    except:
        metadata['date_published'] = "Not found"

    try:
        metadata['publisher'] = soup.find(attrs={'itemprop': 'publisher'}).text
    except:
        metadata['publisher'] = "Not found"

    return metadata

'''

This function will write our list of search results to a csv,
where data is the list of search result items, filename is the name
of the csv file we want to write to, and fieldnames is the list of
field names we want to capture.

'''
def items_to_csv(data, filename, fieldnames):
     with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
          writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
          writer.writeheader()
          writer.writerows(data)


get_items(url)