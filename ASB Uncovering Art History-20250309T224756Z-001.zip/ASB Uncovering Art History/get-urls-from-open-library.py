import requests
from bs4 import BeautifulSoup
import csv

headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:78.0)   Gecko/20100101 Firefox/78.0", 
"Referer": "https://www.google.com"}

# base url to enter search query
url = "https://openlibrary.org/search/inside/"

# search query
parameters = {'q': '\"Archives of American Art, Smithsonian Institution.\"'}

# fieldnames for final csv
fieldnames = ['title', 'url', 'author', 'snippets']

'''

This is a function that loops through search result pages for the query
"Archives of American Art, Smithsonian Institution."

'''
def get_items(url):
    
    items = []

    # loop through search result pages
    for page in range(1,2):

        parameters['page'] = str(page)

        r = requests.get(url, params=parameters, headers=headers)
        print(r.status_code, r.url)

        soup = BeautifulSoup(r.text, 'html.parser')

        for result in soup.find_all(class_='sri__main'):
            snippets = []
            for list_item in result.find_all(class_='fsi-snippet__main fsi-snippet__full-results'):
                    snippets.append(
                         list_item.find(class_='fsi-snippet__link').text.strip().replace('\n', '')
                    )

            item_dict = {}

            item_dict['title'] = result.find(class_='booktitle').text.strip()
            item_dict['url'] = result.find(class_='results')['href']
            item_dict['author'] = result.find(class_='bookauthor').text.strip().replace('\n', '').replace('by ', '')
            item_dict['snippets'] = snippets

            items.append(item_dict)
    return items

'''

This function will write our list of item results to a csv

'''
def items_to_csv(data, filename, fieldnames):
     with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
          writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
          writer.writeheader()
          writer.writerows(data)

items = get_items(url)
items_to_csv(items, 'search-results.csv', fieldnames)